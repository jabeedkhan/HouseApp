//
//  PageViewController.swift
//  HouseApp
//
//  Created by jabeed on 14/12/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class PageViewController: UIPageViewController,UIPageViewControllerDelegate,UIPageViewControllerDataSource {

    
    lazy var orderedViewController:[UIViewController] = {
        
        return [self.newVc(viewController: "Black"),
                self.newVc(viewController: "Red")
        ]
    }()
    
    
    var pageController = UIPageControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.dataSource = self
       if let firstViewController = orderedViewController.first {
            setViewControllers([firstViewController], direction: .forward, animated: true, completion: nil)
            
        }

        
        self.delegate = self
        self.configurePageController()
        // Do any additional setup after loading the view.
    }
    

    
    func configurePageController() {
        pageController = UIPageControl(frame: CGRect(x: 0, y: UIScreen.main.bounds.maxY - 50 , width: UIScreen.main.bounds.width, height: 50))
        pageController.numberOfPages = orderedViewController.count
        pageController.currentPage = 0
        pageController.tintColor = UIColor.blue
        pageController.pageIndicatorTintColor = UIColor.white
        pageController.currentPageIndicatorTintColor = UIColor.black
        self.view.addSubview(pageController)
    }
    
    func newVc(viewController:String)->UIViewController {
        
        let viewController =  UIStoryboard(name:"Main",bundle:nil).instantiateViewController(withIdentifier: viewController)
        
//        viewController.view.backgroundColor = UIColor(red: 85.0/255.0, green: 85.0/255.0, blue: 85.0/255.0, alpha: 0.6);
        
        return viewController
        
    }
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewController.firstIndex(of:viewController) else {
            return nil
        }
        
        let previousIndex = viewControllerIndex - 1
        guard previousIndex >= 0 else {
            // return orderedViewController.last
            return nil
        }
        guard orderedViewController.count > previousIndex else {
            return nil
        }
        return orderedViewController[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewController.firstIndex(of:viewController) else {
            return nil
        }
        
        let nextIndex = viewControllerIndex + 1
        
        guard orderedViewController.count != nextIndex else {
           // return orderedViewController.first
            return nil
        }
        guard  orderedViewController.count > nextIndex else {
            return nil
        }
        return orderedViewController[nextIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        let pageContentViewController = pageViewController.viewControllers![0]
        self.pageController.currentPage = orderedViewController.firstIndex(of: pageContentViewController)!
    }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


