//
//  FirstRoomViewController.swift
//  HouseApp
//
//  Created by jabeed on 15/12/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class FirstRoomViewController: UIViewController {
    
    
    @IBOutlet weak var firstLabel: UILabel!
    @IBOutlet weak var lightOff: UIButton!
    @IBOutlet weak var stateSwitch: UISwitch!
    @IBOutlet weak var deviceLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "view-background.jpg")!)
        let responseJson = appDelegate.parsedJson! as Dictionary<String, AnyObject>
        let devices = responseJson["Devices"] as! Array<AnyObject>
        let deviceObject = devices[0] as! Dictionary<String, AnyObject>

        self.deviceLabel.text = deviceObject["deviceName"] as? String
        
        self.stateSwitch.isOn = Bool(truncating: deviceObject["state"] as! NSNumber)
        
        let house = responseJson["House"] as! Dictionary<String, AnyObject>
        print(house)
        let houseName = house["HouseName"] as! String
        self.firstLabel.text =  houseName
    }
    
    
    @IBAction func clickedButton(_ sender: UISwitch) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "view-background.jpg")!)
        var responseJson = appDelegate.parsedJson! as Dictionary<String, AnyObject>
        var devices = responseJson["Devices"] as! Array<AnyObject>
        var deviceObject = devices[0] as! Dictionary<String, AnyObject>
        
        
        var image:UIImage?
        if stateSwitch.isOn {
            image = UIImage(named: "light-on.png")
            lightOff.setGradientBackground(colorOne: Colors.white, colorTwo: Colors.yellow, colorThree: Colors.white)
            deviceObject["state"] = 1 as AnyObject


        }else {
            image = UIImage(named: "light-off.png")
            lightOff!.layer.sublayers![0].removeFromSuperlayer()
            deviceObject["state"] = 0 as AnyObject

        }
        lightOff.setImage(image!, for: .normal)
        
        print(deviceObject)
    }
    

}
