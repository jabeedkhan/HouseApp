//
//  SecondRoomViewController.swift
//  HouseApp
//
//  Created by jabeed on 15/12/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class SecondRoomViewController: UIViewController {

    @IBOutlet weak var secondLabel: UILabel!
    @IBOutlet weak var dimmLight: UIButton!
    @IBOutlet weak var customSubView: UIView!
    @IBOutlet weak var sideBar: UISlider!
    @IBOutlet weak var deviceLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "view-background.jpg")!)

        // Do any additional setup after loading the view.
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let responseJson = appDelegate.parsedJson! as Dictionary<String, AnyObject>
        let devices = responseJson["Devices"] as! Array<AnyObject>
        let deviceObject = devices[1] as! Dictionary<String, AnyObject>
        
        self.deviceLabel.text = deviceObject["deviceName"] as? String
        
        
        let value = Float(truncating: deviceObject["state"] as! NSNumber)
        
        self.sideBar.setValue(value, animated: false)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let white = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 0.5)
        let yellow = UIColor(red: 225.0/255.0, green: 140.0/255.0, blue: 0.0/255.0, alpha: 0.5)
        dimmLight.setGradientBackground(colorOne: white, colorTwo: yellow, colorThree: white)
    }
    
    
    @IBAction func siderButtonClicked(_ sender: UISlider) {
        let colorValue = CGFloat(sender.value)
        dimmLight!.layer.sublayers![0].removeFromSuperlayer()
        let white = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: colorValue)
        let yellow = UIColor(red: 225.0/255.0, green: 140.0/255.0, blue: 0.0/255.0, alpha: colorValue)
        dimmLight.setGradientBackground(colorOne: white, colorTwo: yellow, colorThree: white)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let responseJson = appDelegate.parsedJson! as Dictionary<String, AnyObject>
        let devices = responseJson["Devices"] as! Array<AnyObject>
        var deviceObject = devices[1] as! Dictionary<String, AnyObject>
        deviceObject["state"] = colorValue as AnyObject
        print(deviceObject)
        let house1 = responseJson["House"] as! Dictionary<String,AnyObject>
        print(house1)
        
        let HouseName = house1["HouseName"] as! String
        self.secondLabel.text = HouseName
        self.secondLabel.textColor = UIColor.white
    }
    


}
